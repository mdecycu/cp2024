import cv2
import numpy as np

# Let's load a simple image with 3 black squares
image = cv2.imread('image.png')

# Grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian blur to reduce noise
blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Threshold the image (adjust threshold value as needed)
_, thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY)

# Finding Contours
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

print("Number of Contours found = " + str(len(contours)))

# Create a copy of the image for labeling
labeled_image = image.copy()

# Draw all contours and add labels
for i, contour in enumerate(contours):
    # Calculate centroid
    M = cv2.moments(contour)
    if M["m00"] != 0:
      cX = int(M["m10"] / M["m00"])
      cY = int(M["m01"] / M["m00"])
    else:
      cX, cY = 0,0


    # Draw contour
    cv2.drawContours(labeled_image, [contour], -1, (0, 255, 0), 3)

    # Label text
    label = str(i + 1)  # Start label from 1
    cv2.putText(
        labeled_image,
        label,
        (cX, cY),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,  # Font size
        (0, 0, 0),  # Text color (black)
        1,  # Line width
        cv2.LINE_AA # Text anti-aliasing
    )

cv2.imshow('Labeled Contours', labeled_image)
cv2.waitKey(0)
cv2.destroyAllWindows()