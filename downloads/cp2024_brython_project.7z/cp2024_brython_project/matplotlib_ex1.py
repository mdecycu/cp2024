import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

data = np.random.rand(100, 100, 3)
print(data)
plt.figure()
plt.imshow(data)
plt.savefig('test_image.png')