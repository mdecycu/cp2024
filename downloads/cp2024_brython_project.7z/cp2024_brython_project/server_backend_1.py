import asyncio
import websockets
import base64

# 接收並處理圖像
async def process_image(websocket):  # 接受兩個參數：websocket 
    print("Server is ready to receive image...")

    try:
        # 接收來自 Brython 的圖像數據（base64 編碼）
        image_data = await websocket.recv()
        print("Image received from client...")

        # 直接回傳收到的圖像數據給 Brython 端
        await websocket.send(image_data)
        print("Image sent back to client...")

    except Exception as e:
        print(f"Error during image processing: {e}")

# 啟動 WebSocket 伺服器
async def main():
    async with websockets.serve(process_image, "localhost", 8888):
        await asyncio.Future()  # run forever

# 啟動伺服器
asyncio.run(main())
