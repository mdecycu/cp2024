import asyncio
import websockets
import cv2
import numpy as np
from PIL import Image, ImageDraw
import io
import base64

# 接收並處理圖像
async def process_image(websocket):  # 接受兩個參數：websocket 和 path
    print("Server is ready to receive image...")

    try:
        # 接收來自 Brython 的圖像數據（base64 編碼）
        image_data = await websocket.recv()
        print("Image received from client...")

        # 解碼 base64 圖像數據
        image_data = base64.b64decode(image_data)

        # 將圖像數據轉換為 PIL 圖像
        image = Image.open(io.BytesIO(image_data))
        print("Image loaded into server...")

        # 轉換為 OpenCV 格式進行處理
        open_cv_image = np.array(image)
        open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGB2BGR)

        # 辨識圓形與正方形，並塗色
        processed_image = process_image_regions(open_cv_image)

        # 通知進度：處理完成
        print("Image processing completed...")

        # 將處理後的圖像轉換回 PIL 以便傳回給前端
        processed_image_pil = Image.fromarray(cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB))

        # 儲存處理過的圖像並轉換為 base64
        buffered = io.BytesIO()
        processed_image_pil.save(buffered, format="PNG")
        processed_image_data = base64.b64encode(buffered.getvalue()).decode('utf-8')

        # 回傳處理過的圖像數據到前端
        print("Sending processed image back to client...")
        await websocket.send(processed_image_data)

    except Exception as e:
        print(f"Error during image processing: {e}")

# 進行封閉區域辨識並填充顏色
def process_image_regions(image):
    # 轉換為灰度圖
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (15, 15), 0)

    # 偵測圓形
    circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, 1, 20, param1=50, param2=30, minRadius=50, maxRadius=200)

    if circles is not None:
        circles = np.round(circles[0, :]).astype("int")
        for (x, y, r) in circles:
            # 在圓形周圍畫一個圓
            cv2.circle(image, (x, y), r, (0, 255, 0), 4)  # 畫圓

            # 填充圓形內部
            cv2.circle(image, (x, y), r, (0, 255, 0), -1)  # 填充綠色

    # 使用 Canny 邊緣檢測來找到正方形
    edges = cv2.Canny(gray, 100, 200)

    # 查找輪廓
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        # 用多邊形逼近輪廓
        epsilon = 0.04 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)

        # 如果輪廓是四邊形（正方形或矩形）
        if len(approx) == 4:
            # 塗上綠色
            cv2.drawContours(image, [approx], -1, (0, 255, 0), -1)

    # 返回處理過的圖像
    return image

# 啟動 WebSocket 伺服器
async def main():
    async with websockets.serve(process_image, "localhost", 8888):
        await asyncio.Future()  # run forever

# 啟動伺服器
asyncio.run(main())
