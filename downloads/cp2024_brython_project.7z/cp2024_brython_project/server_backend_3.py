import asyncio
import websockets
import cv2
import numpy as np
from PIL import Image
import io
import base64
import matplotlib.pyplot as plt

# 接收並處理圖像
async def process_image(websocket):
    print("Server is ready to receive image...")

    try:
        # 接收來自 Brython 的圖像數據（base64 編碼）
        image_data = await websocket.recv()
        print(f"Step 1: Image received from client. Data length: {len(image_data)} characters.")

        # 解碼 base64 圖像數據
        image_data = base64.b64decode(image_data)
        print(f"Step 2: Image data decoded from base64. Data length: {len(image_data)} bytes.")

        # 顯示圖像數據的前幾個字節
        print("First 50 bytes of received image data:", image_data[:50])

        # 將圖像數據轉換為 PIL 圖像
        image = Image.open(io.BytesIO(image_data))
        print("Step 3: Image loaded into server (PIL format)...")

        # 顯示接收到的圖像，檢查接收是否正常
        show_image("Received Image", np.array(image))

        # 轉換為 OpenCV 格式進行處理
        open_cv_image = np.array(image)
        open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGB2BGR)
        print("Step 4: Image converted to OpenCV format...")

        # 顯示 OpenCV 圖像，檢查轉換結果
        show_image("Original OpenCV Image", open_cv_image)

        # 辨識封閉區域並填充顏色
        processed_image, centroids = process_image_regions(open_cv_image)
        print(f"Step 5: Processed image. {len(centroids)} regions found and filled with colors.")

        # 通知進度：處理完成
        print("Step 6: Image processing completed...")

        # 顯示處理後的圖像
        show_image("Processed Image", processed_image)

        # 將處理後的圖像轉換回 PIL 以便傳回給前端
        processed_image_pil = Image.fromarray(cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB))

        # 儲存處理過的圖像並轉換為 base64
        buffered = io.BytesIO()
        processed_image_pil.save(buffered, format="PNG")
        processed_image_data = base64.b64encode(buffered.getvalue()).decode('utf-8')
        print("Step 7: Processed image saved and converted to base64...")

        # 回傳處理過的圖像數據到前端
        print("Step 8: Sending processed image back to client...")
        await websocket.send(processed_image_data)

    except Exception as e:
        print(f"Error during image processing: {e}")


# 顯示圖像的函式
def show_image(title, image):
    plt.figure(figsize=(6, 6))
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    plt.title(title)
    plt.axis('off')  # 不顯示坐標軸
    plt.show()


# 進行封閉區域辨識並填充顏色
def process_image_regions(image):
    print("Starting contour detection and color filling...")
    
    # 轉換為灰度圖
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    print("Step 1: Image converted to grayscale and blurred for edge detection.")

    # 使用 Canny 邊緣檢測來找到邊界
    edges = cv2.Canny(blurred, 50, 150)
    print("Step 2: Edge detection using Canny completed.")

    # 查找輪廓
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"Step 3: Found {len(contours)} contours in the image.")

    centroids = []  # 儲存質心座標

    for contour in contours:
        # 計算每個輪廓的質心
        M = cv2.moments(contour)
        if M["m00"] != 0:  # 防止除以零
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            centroids.append((cx, cy))  # 儲存質心座標
            # 在圖像上標註質心
            cv2.circle(image, (cx, cy), 5, (0, 0, 255), -1)  # 使用紅色標註質心
    print(f"Step 4: {len(centroids)} centroids calculated.")

    # 塗色封閉區域（根據質心著色）
    for idx, contour in enumerate(contours):
        color = (np.random.randint(0, 256), np.random.randint(0, 256), np.random.randint(0, 256))  # 隨機顏色
        cv2.drawContours(image, [contour], -1, color, -1)  # 塗色

    print("Step 5: Contours filled with random colors.")

    # 返回處理過的圖像
    return image, centroids


# 啟動 WebSocket 伺服器
async def main():
    print("Starting WebSocket server on ws://localhost:8888...")
    async with websockets.serve(process_image, "localhost", 8888):
        await asyncio.Future()  # run forever

# 啟動伺服器
asyncio.run(main())
