import asyncio
import websockets
import base64
from io import BytesIO
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import os

print("Python: Start server.py")

async def handle_websocket(websocket, path="/"):
    print("Python: handle_websocket - New WebSocket connection")
    try:
        async for message in websocket:
            print("Python: handle_websocket - Received image data")
            # 解碼base64
            image_data = base64.b64decode(message)
            print(f"Python: handle_websocket - Image data decoded length: {len(image_data)}")
            print(f"Python: handle_websocket - Image data decoded first 10 bytes: {image_data[:10]}")
           
            # 從二進位資料讀取圖片
            image_stream = BytesIO(image_data)
            try:
                image = Image.open(image_stream)
                print("Python: handle_websocket - Image opened")
            except Exception as e:
                print(f"Python: handle_websocket - Error opening image: {e}")
                continue # 跳過此訊息，避免中斷程式。

            image_np = np.array(image)
            print(f"Python: handle_websocket - Image converted to numpy array shape: {image_np.shape}")
            print(f"Python: handle_websocket - Image converted to numpy array data: {image_np.flatten()[:10]}")
            print(f"Python: handle_websocket - Image converted to numpy array min: {image_np.min()}, max: {image_np.max()}, dtype: {image_np.dtype}")
            
            # 顯示接收到的原始圖像 (使用 plt.show())
            # Display using matplotlib
            plt.figure()
            plt.imshow(image_np) # Display the numpy array
            plt.title("Received Image")
            plt.axis('off')  # optional: remove axes
            plt.show()
            '''
            plt.figure(figsize=(5,5))
            plt.imshow(image_np, cmap='gray') # 嘗試使用灰階色彩映射表
            plt.title('Received Original Image')
            plt.axis('off')
            plt.show()
            '''
            print(f"Python: handle_websocket - Original Image displayed")
           
            # 將原始的圖像數據原封不動地回傳
            processed_base64_data = base64.b64encode(image_data).decode('utf-8')
            print("Python: handle_websocket - Sending original image back")
            await websocket.send(processed_base64_data)
            print("Python: handle_websocket - Original image sent back")

    except Exception as e:
        print(f"Python: handle_websocket - Error processing message: {e}")
    print("Python: handle_websocket - WebSocket connection closed")

async def main():
    print("Python: main - Start")
    async with websockets.serve(handle_websocket, "localhost", 8888):
        print("Python: main - WebSocket server started at ws://localhost:8888")
        await asyncio.Future()  # Run forever
    print("Python: main - End")

if __name__ == "__main__":
    print("Python: __main__ - Starting server")
    asyncio.run(main())