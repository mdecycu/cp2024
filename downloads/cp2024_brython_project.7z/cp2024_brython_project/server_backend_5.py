import asyncio
import websockets
import base64
from io import BytesIO
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2

print("Python: Start server.py")

def process_image(image):
    """Processes the image to find and label closed regions with numbers."""
    
    image_np = np.array(image)
    
    # Convert to grayscale
    gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    print(f"Python: process_image - Grayscale Image shape: {gray.shape}")

    # Blur the image
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    # gray = cv2.medianBlur(gray, 5) #alternative blur method

    # Thresholding
    # _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    # _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
    # thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)
    # thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)


    plt.figure()
    plt.imshow(gray, cmap="gray")
    plt.title("Gray")
    plt.show()

    plt.figure()
    plt.imshow(thresh, cmap="gray")
    plt.title("threshold")
    plt.show()

    
    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    print(f"Python: process_image - Contours found: {len(contours)}")
    
    # Show contours
    contour_image = image_np.copy()
    cv2.drawContours(contour_image, contours, -1, (0, 255, 0), 3)
    plt.figure()
    plt.imshow(contour_image)
    plt.title("contours")
    plt.show()


    # Create a copy of the image for labeling
    labeled_image = image_np.copy()

    # Add text labels to each contour
    for i, contour in enumerate(contours):
        print(f"Python: process_image - contour shape {contour.shape}")
        # Calculate centroid
        M = cv2.moments(contour)
        if M["m00"] != 0:
          cX = int(M["m10"] / M["m00"])
          cY = int(M["m01"] / M["m00"])
        else:
          cX, cY = 0,0

        # Label text
        label = str(i + 1)  # Start label from 1
        cv2.putText(
            labeled_image,
            label,
            (cX, cY),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,  # Font size
            (0, 0, 0),  # Text color (black)
            2,         # Line width
            cv2.LINE_AA
        )

    processed_image = Image.fromarray(labeled_image)
    return processed_image

async def handle_websocket(websocket, path="/"):
    print("Python: handle_websocket - New WebSocket connection")
    try:
        async for message in websocket:
            print("Python: handle_websocket - Received image data")
            # 解碼base64
            image_data = base64.b64decode(message)
            print(f"Python: handle_websocket - Image data decoded length: {len(image_data)}")
            print(f"Python: handle_websocket - Image data decoded first 10 bytes: {image_data[:10]}")
           
            # 從二進位資料讀取圖片
            image_stream = BytesIO(image_data)
            try:
                image = Image.open(image_stream)
                print("Python: handle_websocket - Image opened")
            except Exception as e:
                print(f"Python: handle_websocket - Error opening image: {e}")
                continue # 跳過此訊息，避免中斷程式。

            image_np = np.array(image)
            print(f"Python: handle_websocket - Image converted to numpy array shape: {image_np.shape}")
            print(f"Python: handle_websocket - Image converted to numpy array data: {image_np.flatten()[:10]}")
            print(f"Python: handle_websocket - Image converted to numpy array min: {image_np.min()}, max: {image_np.max()}, dtype: {image_np.dtype}")
            
            # Process the image
            processed_image = process_image(image)
            processed_image_np = np.array(processed_image)

            # Display the processed image
            plt.figure()
            plt.imshow(processed_image_np)
            plt.title("Processed Image")
            plt.axis('off')
            plt.show()
            print(f"Python: handle_websocket - Processed Image displayed")
           
            # Prepare processed image for sending back to client
            processed_image_stream = BytesIO()
            processed_image.save(processed_image_stream, format="PNG")
            processed_image_data = processed_image_stream.getvalue()

            # Encode the processed data in base64 and send back
            processed_base64_data = base64.b64encode(processed_image_data).decode('utf-8')
            print("Python: handle_websocket - Sending processed image back")
            await websocket.send(processed_base64_data)
            print("Python: handle_websocket - Processed image sent back")

    except Exception as e:
        print(f"Python: handle_websocket - Error processing message: {e}")
    print("Python: handle_websocket - WebSocket connection closed")


async def main():
    print("Python: main - Start")
    async with websockets.serve(handle_websocket, "localhost", 8888):
        print("Python: main - WebSocket server started at ws://localhost:8888")
        await asyncio.Future()  # Run forever
    print("Python: main - End")

if __name__ == "__main__":
    print("Python: __main__ - Starting server")
    asyncio.run(main())