import sqlite3

def list_all_data_in_db(db_file):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Retrieve the list of tables in the database
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    
    # Iterate over each table and fetch all data
    for table in tables:
        table_name = table[0]
        print(f"Data from table: {table_name}")
        
        # Fetch column names (field titles)
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = cursor.fetchall()
        column_names = [column[1] for column in columns]
        
        # Print column names (field titles) as the header
        print("\t".join(column_names))
        
        # Fetch all data from the table
        cursor.execute(f"SELECT * FROM {table_name}")
        rows = cursor.fetchall()
        
        # Print the data rows
        for row in rows:
            print("\t".join(str(cell) for cell in row))
        
        print("\n" + "="*50 + "\n")
    
    # Close the connection
    conn.close()

# Example usage
db_file = 'lewis.db'  # Replace with the path to your SQLite database
list_all_data_in_db(db_file)