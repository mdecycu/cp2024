import PyPDF2

# 開啟 PDF 檔案
with open('learn_python_with_jupyter.pdf', 'rb') as file:
    reader = PyPDF2.PdfReader(file)
    text = ''
    
    # 遍歷每一頁
    for page in reader.pages:
        text += page.extract_text() + '\n'

print(text)