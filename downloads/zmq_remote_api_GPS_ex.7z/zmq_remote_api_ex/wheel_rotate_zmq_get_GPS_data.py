from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import time
import math
import keyboard

# 利用 zmqRemoteAPI 以 23000 對場景伺服器進行連線
client = RemoteAPIClient('[::1]', 23000)
# 以 getObject 方法取得場景物件
sim = client.getObject('sim')
box = sim.getObject('/box')

# 啟動模擬
sim.startSimulation()

# 取得平台的位置座標
platform_handle = sim.getObject('/plate_dyn')
platform_pos = sim.getObjectPosition(platform_handle, -1)
platform_xyz = [platform_pos[0], platform_pos[1], platform_pos[2]]
GPS_handle = sim.getObject('/GPS')

right_wheel_joint_handle = sim.getObject('/right_wheel_joint')
left_wheel_joint_handle = sim.getObject('/left_wheel_joint')

# 設定主迴圈
while True:
    # 設定目標速度
    if keyboard.is_pressed('r'):
        sim.setJointTargetVelocity(right_wheel_joint_handle, 1)
    if keyboard.is_pressed('e'):
        sim.setJointTargetVelocity(right_wheel_joint_handle, -1)

    # 讀取 GPS 的數據
    sensorScript = sim.getScript(sim.scripttype_childscript, GPS_handle)
    GPSData = sim.callScriptFunction('getGPSData', sensorScript)

    if GPSData:
        # 這裡的 sensor_data 需要根據實際的返回格式來解析
        print(f'GPSSensor data: {GPSData}')

    # 讓 CoppeliaSim 有時間按照設定讓 joint1 旋轉
    time.sleep(0.1)  # 增加延遲以便更穩定地讀取數據

    if keyboard.is_pressed('q'):
        # 可以按下 q 鍵跳出重複執行迴圈
        break


# 終止模擬
sim.stopSimulation()