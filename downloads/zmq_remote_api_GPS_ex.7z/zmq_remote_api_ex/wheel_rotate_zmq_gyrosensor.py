from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import time
import math
import keyboard

# 利用 zmqRemoteAPI 以 23000 對場景伺服器進行連線
client = RemoteAPIClient('[::1]', 23000)
# 以 getObject 方法取得場景物件
sim = client.getObject('sim')
box = sim.getObject('/box')

# 啟動模擬
sim.startSimulation()

# 建立尺寸數列, 分別定義 x, y, z 方向尺寸
x = 2.0
y = 2.0
z = 0.1
size = [x, y, z]

# 利用 size 數列, 建立圓柱物件
digit1_handle = sim.createPrimitiveShape(sim.primitiveshape_cylinder, size, 0)
sim.setObjectAlias(digit1_handle, 'digit1')
sim.setObjectOrientation(digit1_handle, -1, [0, math.pi/2, 0])
sim.setObjectPosition(digit1_handle, -1, [0, 0, x/2])

# 將 digit1 設為動態
# 設置質量屬性
sim.setObjectFloatParam(digit1_handle, sim.shapefloatparam_mass , 1.0)
# 設置物體為動態
sim.setObjectInt32Param(digit1_handle, sim.shapeintparam_static, 0)
sim.resetDynamicObject(digit1_handle)
# 設為具備碰撞檢測屬性
sim.setObjectInt32Param(digit1_handle, sim.shapeintparam_respondable , 1)

# 建立 revolute joint 命名為 joint, 且將 joint mode 設為 dynamic, control mode 設為 velocity
joint1_handle = sim.createJoint(sim.joint_revolute_subtype, sim.jointmode_dynamic, 0, None)
sim.setObjectInt32Param(joint1_handle, sim.jointintparam_dynctrlmode, sim.jointdynctrl_velocity)
sim.setObjectAlias(joint1_handle, 'joint1')

# 取得 cylinder 的位置座標
digit1_pos = sim.getObjectPosition(digit1_handle, -1)
joint1_pos = [digit1_pos[0], digit1_pos[1], digit1_pos[2]]

# 將 joint1 至於 cylinder 中心
sim.setObjectPosition(joint1_handle, -1, joint1_pos)
# 取得 digit1_handle 的方位
digit1_ori = sim.getObjectOrientation(digit1_handle, -1)
# 將 joint1_handle 方位與 digit1 對齊
sim.setObjectOrientation(joint1_handle, -1, digit1_ori)

# 將 joint1 置於 box 上
sim.setObjectParent(joint1_handle, box, True)
# 將 cylinder 置於 joint1 上
sim.setObjectParent(digit1_handle, joint1_handle, True)

# 鎖定 joint1
sim.setJointTargetForce(joint1_handle, float('inf'))

print("基本場景建立完成!")

sensor = sim.createPrimitiveShape(sim.primitiveshape_cylinder, [0.1,0.1,0.1], 0)
sim.setObjectAlias(sensor, 'sensor')
sim.setObjectPosition(sensor, -1, [0, x/2, 0])

# 載入 GyroSensor2 模型
# 由 https://forum.coppeliarobotics.com/viewtopic.php?t=10206 修改, 可讀出 gyrodata
gyro_model_path = 'models/components/sensors/GyroSensor2.ttm'
gyro_handle = sim.loadModel(gyro_model_path)

# 確保 GyroSensor 在圓柱物件上
sim.setObjectPosition(gyro_handle, sensor, [0, 0, 0])
sim.setObjectParent(gyro_handle, sensor, True)

# 取得 GyroSensor 的句柄
# 通常模型載入後的物件名稱是 'GyroSensor'
gyro_sensor_handle = sim.getObject('/GyroSensor2')

# 設定主迴圈
while True:
    # 設定 joint1 目標速度
    sim.setJointTargetVelocity(joint1_handle, 10)

    # 嘗試讀取 GyroSensor 的數據
    sensorScript = sim.getScript(sim.scripttype_childscript, gyro_handle)
    gyroData = sim.callScriptFunction('getGyroData', sensorScript)

    if gyroData:
        # 這裡的 sensor_data 需要根據實際的返回格式來解析
        print(f'GyroSensor data: {gyroData}')

    # 讓 CoppeliaSim 有時間按照設定讓 joint1 旋轉
    time.sleep(0.1)  # 增加延遲以便更穩定地讀取數據

    if keyboard.is_pressed('q'):
        # 可以按下 q 鍵跳出重複執行迴圈
        break

# 終止模擬
sim.stopSimulation()